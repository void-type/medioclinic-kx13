SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [Proc_CMS_ScheduledTask_FetchTasksToRun]
    @TaskSiteID int,
    @DateTime datetime2(7),
    @TaskServerName nvarchar(100),
    @BatchSize int,
    @LastProcessedId int,
    @TaskType int,
    @UseExternalService bit = null
AS
BEGIN
    SET NOCOUNT ON;
    /* All tasks have to always have ID greater than last ID processed and Status equal to Ready (not Running nor Disabled) and
       NextRunTime greater than provided DateTime. Also tasks that run only Once have no NextRunTime and can be omitted in all cases. */

    IF (@TaskSiteID IS NOT NULL)
    BEGIN
        /* Get tasks for specified site and global tasks that should be processed by application */
        IF (@UseExternalService = 0)
        BEGIN
            ;WITH q AS
            (
                SELECT TOP(@BatchSize) [TaskID], [TaskName], [TaskDisplayName], [TaskAssemblyName], [TaskClass], [TaskInterval], [TaskData], [TaskLastRunTime],
                    [TaskNextRunTime], [TaskEnabled], [TaskIsRunning], [TaskSiteID], [TaskDeleteAfterLastRun], [TaskServerName], [TaskGUID], [TaskExecutions],
                    [TaskResourceID], [TaskRunInSeparateThread], [TaskUseExternalService], [TaskAllowExternalService], [TaskLastExecutionReset], [TaskCondition],
                    [TaskRunIndividually], [TaskUserID], [TaskType], [TaskObjectType], [TaskObjectID], [TaskExecutingServerName], [TaskAvailability]
                FROM CMS_ScheduledTask
                WHERE TaskID > @LastProcessedId AND TaskNextRunTime IS NOT NULL AND TaskNextRunTime <= @DateTime AND TaskEnabled = 1 AND TaskIsRunning = 0 AND TaskAvailability = 0
                    AND (TaskSiteID = @TaskSiteID OR TaskSiteID IS NULL)
                    AND (TaskServerName IS NULL OR TaskServerName = '' OR TaskServerName = @TaskServerName)
                    AND (TaskUseExternalService = 0 OR TaskUseExternalService IS NULL)
                ORDER BY TaskID
            )
            UPDATE q SET TaskIsRunning = 1, TaskExecutingServerName = @TaskServerName
                OUTPUT INSERTED.[TaskID], INSERTED.[TaskName], INSERTED.[TaskDisplayName], INSERTED.[TaskAssemblyName], INSERTED.[TaskClass], INSERTED.[TaskInterval], INSERTED.[TaskData], INSERTED.[TaskLastRunTime],
                    INSERTED.[TaskNextRunTime], INSERTED.[TaskEnabled], INSERTED.[TaskIsRunning], INSERTED.[TaskSiteID], INSERTED.[TaskDeleteAfterLastRun], INSERTED.[TaskServerName], INSERTED.[TaskGUID], INSERTED.[TaskExecutions],
                    INSERTED.[TaskResourceID], INSERTED.[TaskRunInSeparateThread], INSERTED.[TaskUseExternalService], INSERTED.[TaskAllowExternalService], INSERTED.[TaskLastExecutionReset], INSERTED.[TaskCondition],
                    INSERTED.[TaskRunIndividually], INSERTED.[TaskUserID], INSERTED.[TaskType], INSERTED.[TaskObjectType], INSERTED.[TaskObjectID], INSERTED.[TaskExecutingServerName], INSERTED.[TaskAvailability]
        END
        ELSE IF (@UseExternalService = 1)
        /* Get tasks for specified site and global tasks that should be processed by external service */
        BEGIN
            ;WITH q AS
            (
                SELECT TOP(@BatchSize) [TaskID], [TaskName], [TaskDisplayName], [TaskAssemblyName], [TaskClass], [TaskInterval], [TaskData], [TaskLastRunTime],
                    [TaskNextRunTime], [TaskEnabled], [TaskIsRunning], [TaskSiteID], [TaskDeleteAfterLastRun], [TaskServerName], [TaskGUID], [TaskExecutions],
                    [TaskResourceID], [TaskRunInSeparateThread], [TaskUseExternalService], [TaskAllowExternalService], [TaskLastExecutionReset], [TaskCondition],
                    [TaskRunIndividually], [TaskUserID], [TaskType], [TaskObjectType], [TaskObjectID], [TaskExecutingServerName], [TaskAvailability]
                FROM CMS_ScheduledTask
                WHERE TaskID > @LastProcessedId AND TaskNextRunTime IS NOT NULL AND TaskNextRunTime <= @DateTime AND TaskEnabled = 1 AND TaskIsRunning = 0 AND TaskAvailability = 0
                    AND (TaskSiteID = @TaskSiteID OR TaskSiteID IS NULL)
                    AND (TaskServerName IS NULL OR TaskServerName = '' OR TaskServerName = @TaskServerName)
                    AND (TaskUseExternalService = 1)
                ORDER BY TaskID
            )
            UPDATE q SET TaskIsRunning = 1, TaskExecutingServerName = @TaskServerName
                OUTPUT INSERTED.[TaskID], INSERTED.[TaskName], INSERTED.[TaskDisplayName], INSERTED.[TaskAssemblyName], INSERTED.[TaskClass], INSERTED.[TaskInterval], INSERTED.[TaskData], INSERTED.[TaskLastRunTime],
                    INSERTED.[TaskNextRunTime], INSERTED.[TaskEnabled], INSERTED.[TaskIsRunning], INSERTED.[TaskSiteID], INSERTED.[TaskDeleteAfterLastRun], INSERTED.[TaskServerName], INSERTED.[TaskGUID], INSERTED.[TaskExecutions],
                    INSERTED.[TaskResourceID], INSERTED.[TaskRunInSeparateThread], INSERTED.[TaskUseExternalService], INSERTED.[TaskAllowExternalService], INSERTED.[TaskLastExecutionReset], INSERTED.[TaskCondition],
                    INSERTED.[TaskRunIndividually], INSERTED.[TaskUserID], INSERTED.[TaskType], INSERTED.[TaskObjectType], INSERTED.[TaskObjectID], INSERTED.[TaskExecutingServerName], INSERTED.[TaskAvailability]
        END
        ELSE IF (@UseExternalService IS NULL)
        /* Get live site tasks or administration tasks if external scheduler is disabled */
        BEGIN
			IF (@TaskType = 0)
			/* Get administration tasks for specified site and global tasks */
			BEGIN
				;WITH q AS
				(
					SELECT TOP(@BatchSize) [TaskID], [TaskName], [TaskDisplayName], [TaskAssemblyName], [TaskClass], [TaskInterval], [TaskData], [TaskLastRunTime],
						[TaskNextRunTime], [TaskEnabled], [TaskIsRunning], [TaskSiteID], [TaskDeleteAfterLastRun], [TaskServerName], [TaskGUID], [TaskExecutions],
						[TaskResourceID], [TaskRunInSeparateThread], [TaskUseExternalService], [TaskAllowExternalService], [TaskLastExecutionReset], [TaskCondition],
						[TaskRunIndividually], [TaskUserID], [TaskType], [TaskObjectType], [TaskObjectID], [TaskExecutingServerName], [TaskAvailability]
					FROM CMS_ScheduledTask
					WHERE TaskID > @LastProcessedId AND TaskNextRunTime IS NOT NULL AND TaskNextRunTime <= @DateTime AND TaskEnabled = 1 AND TaskIsRunning = 0 AND TaskAvailability = 0
						AND (TaskSiteID = @TaskSiteID OR TaskSiteID IS NULL)
						AND (TaskServerName IS NULL OR TaskServerName = '' OR TaskServerName = @TaskServerName)
					ORDER BY TaskID
				)
				UPDATE q SET TaskIsRunning = 1, TaskExecutingServerName = @TaskServerName
					OUTPUT INSERTED.[TaskID], INSERTED.[TaskName], INSERTED.[TaskDisplayName], INSERTED.[TaskAssemblyName], INSERTED.[TaskClass], INSERTED.[TaskInterval], INSERTED.[TaskData], INSERTED.[TaskLastRunTime],
						INSERTED.[TaskNextRunTime], INSERTED.[TaskEnabled], INSERTED.[TaskIsRunning], INSERTED.[TaskSiteID], INSERTED.[TaskDeleteAfterLastRun], INSERTED.[TaskServerName], INSERTED.[TaskGUID], INSERTED.[TaskExecutions],
						INSERTED.[TaskResourceID], INSERTED.[TaskRunInSeparateThread], INSERTED.[TaskUseExternalService], INSERTED.[TaskAllowExternalService], INSERTED.[TaskLastExecutionReset], INSERTED.[TaskCondition],
						INSERTED.[TaskRunIndividually], INSERTED.[TaskUserID], INSERTED.[TaskType], INSERTED.[TaskObjectType], INSERTED.[TaskObjectID], INSERTED.[TaskExecutingServerName], INSERTED.[TaskAvailability]
			END
			ELSE
			/* Get live site tasks for specified site */
			BEGIN
				;WITH q AS
				(
					SELECT TOP(@BatchSize) [TaskID], [TaskName], [TaskDisplayName], [TaskAssemblyName], [TaskClass], [TaskInterval], [TaskData], [TaskLastRunTime],
						[TaskNextRunTime], [TaskEnabled], [TaskIsRunning], [TaskSiteID], [TaskDeleteAfterLastRun], [TaskServerName], [TaskGUID], [TaskExecutions],
						[TaskResourceID], [TaskRunInSeparateThread], [TaskUseExternalService], [TaskAllowExternalService], [TaskLastExecutionReset], [TaskCondition],
						[TaskRunIndividually], [TaskUserID], [TaskType], [TaskObjectType], [TaskObjectID], [TaskExecutingServerName], [TaskAvailability]
					FROM CMS_ScheduledTask
					WHERE TaskID > @LastProcessedId AND TaskNextRunTime IS NOT NULL AND TaskNextRunTime <= @DateTime AND TaskEnabled = 1 AND TaskIsRunning = 0 AND TaskAvailability = 1
						AND (TaskSiteID = @TaskSiteID)
						AND (TaskServerName IS NULL OR TaskServerName = '' OR TaskServerName = @TaskServerName)
					ORDER BY TaskID
				)
				UPDATE q SET TaskIsRunning = 1, TaskExecutingServerName = @TaskServerName
					OUTPUT INSERTED.[TaskID], INSERTED.[TaskName], INSERTED.[TaskDisplayName], INSERTED.[TaskAssemblyName], INSERTED.[TaskClass], INSERTED.[TaskInterval], INSERTED.[TaskData], INSERTED.[TaskLastRunTime],
						INSERTED.[TaskNextRunTime], INSERTED.[TaskEnabled], INSERTED.[TaskIsRunning], INSERTED.[TaskSiteID], INSERTED.[TaskDeleteAfterLastRun], INSERTED.[TaskServerName], INSERTED.[TaskGUID], INSERTED.[TaskExecutions],
						INSERTED.[TaskResourceID], INSERTED.[TaskRunInSeparateThread], INSERTED.[TaskUseExternalService], INSERTED.[TaskAllowExternalService], INSERTED.[TaskLastExecutionReset], INSERTED.[TaskCondition],
						INSERTED.[TaskRunIndividually], INSERTED.[TaskUserID], INSERTED.[TaskType], INSERTED.[TaskObjectType], INSERTED.[TaskObjectID], INSERTED.[TaskExecutingServerName], INSERTED.[TaskAvailability]
			END
        END
    END
    ELSE
    BEGIN
        IF (@UseExternalService = 1)
        /* Get sites and global tasks for external service (only for running sites) */
        BEGIN
            ;WITH q AS
            (
                SELECT TOP(@BatchSize) [TaskID], [TaskName], [TaskDisplayName], [TaskAssemblyName], [TaskClass], [TaskInterval], [TaskData], [TaskLastRunTime],
                    [TaskNextRunTime], [TaskEnabled], [TaskIsRunning], [TaskSiteID], [TaskDeleteAfterLastRun], [TaskServerName], [TaskGUID], [TaskExecutions],
                    [TaskResourceID], [TaskRunInSeparateThread], [TaskUseExternalService], [TaskAllowExternalService], [TaskLastExecutionReset], [TaskCondition],
                    [TaskRunIndividually], [TaskUserID], [TaskType], [TaskObjectType], [TaskObjectID], [TaskExecutingServerName], [TaskAvailability]
                FROM CMS_ScheduledTask
                WHERE TaskID > @LastProcessedId AND TaskNextRunTime IS NOT NULL AND TaskNextRunTime <= @DateTime AND TaskEnabled = 1 AND TaskIsRunning = 0 AND TaskAvailability = 0
                    AND (TaskSiteID IN (SELECT SiteID FROM CMS_Site WHERE SiteStatus = N'RUNNING') OR TaskSiteID IS NULL)
                    AND (TaskServerName IS NULL OR TaskServerName = '' OR TaskServerName = @TaskServerName)
                    AND (TaskUseExternalService = 1)
                ORDER BY TaskID
            )
            UPDATE q SET TaskIsRunning = 1, TaskExecutingServerName = @TaskServerName
                OUTPUT INSERTED.[TaskID], INSERTED.[TaskName], INSERTED.[TaskDisplayName], INSERTED.[TaskAssemblyName], INSERTED.[TaskClass], INSERTED.[TaskInterval], INSERTED.[TaskData], INSERTED.[TaskLastRunTime],
                    INSERTED.[TaskNextRunTime], INSERTED.[TaskEnabled], INSERTED.[TaskIsRunning], INSERTED.[TaskSiteID], INSERTED.[TaskDeleteAfterLastRun], INSERTED.[TaskServerName], INSERTED.[TaskGUID], INSERTED.[TaskExecutions],
                    INSERTED.[TaskResourceID], INSERTED.[TaskRunInSeparateThread], INSERTED.[TaskUseExternalService], INSERTED.[TaskAllowExternalService], INSERTED.[TaskLastExecutionReset], INSERTED.[TaskCondition],
                    INSERTED.[TaskRunIndividually], INSERTED.[TaskUserID], INSERTED.[TaskType], INSERTED.[TaskObjectType], INSERTED.[TaskObjectID], INSERTED.[TaskExecutingServerName], INSERTED.[TaskAvailability]
        END
        ELSE IF (@UseExternalService IS NULL)
        /* Get only global tasks if there is no site */
        BEGIN
            ;WITH q AS
            (
                SELECT TOP(@BatchSize) [TaskID], [TaskName], [TaskDisplayName], [TaskAssemblyName], [TaskClass], [TaskInterval], [TaskData], [TaskLastRunTime],
                    [TaskNextRunTime], [TaskEnabled], [TaskIsRunning], [TaskSiteID], [TaskDeleteAfterLastRun], [TaskServerName], [TaskGUID], [TaskExecutions],
                    [TaskResourceID], [TaskRunInSeparateThread], [TaskUseExternalService], [TaskAllowExternalService], [TaskLastExecutionReset], [TaskCondition],
                    [TaskRunIndividually], [TaskUserID], [TaskType], [TaskObjectType], [TaskObjectID], [TaskExecutingServerName], [TaskAvailability]
                FROM CMS_ScheduledTask
                WHERE TaskID > @LastProcessedId AND TaskNextRunTime IS NOT NULL AND TaskNextRunTime <= @DateTime AND TaskEnabled = 1 AND TaskIsRunning = 0 AND TaskAvailability = 0
					AND (TaskSiteID IS NULL)
                    AND (TaskServerName IS NULL OR TaskServerName = '' OR TaskServerName = @TaskServerName)
                ORDER BY TaskID
            )
            UPDATE q SET TaskIsRunning = 1, TaskExecutingServerName = @TaskServerName
                OUTPUT INSERTED.[TaskID], INSERTED.[TaskName], INSERTED.[TaskDisplayName], INSERTED.[TaskAssemblyName], INSERTED.[TaskClass], INSERTED.[TaskInterval], INSERTED.[TaskData], INSERTED.[TaskLastRunTime],
                    INSERTED.[TaskNextRunTime], INSERTED.[TaskEnabled], INSERTED.[TaskIsRunning], INSERTED.[TaskSiteID], INSERTED.[TaskDeleteAfterLastRun], INSERTED.[TaskServerName], INSERTED.[TaskGUID], INSERTED.[TaskExecutions],
                    INSERTED.[TaskResourceID], INSERTED.[TaskRunInSeparateThread], INSERTED.[TaskUseExternalService], INSERTED.[TaskAllowExternalService], INSERTED.[TaskLastExecutionReset], INSERTED.[TaskCondition],
                    INSERTED.[TaskRunIndividually], INSERTED.[TaskUserID], INSERTED.[TaskType], INSERTED.[TaskObjectType], INSERTED.[TaskObjectID], INSERTED.[TaskExecutingServerName], INSERTED.[TaskAvailability]
        END
    END
END
GO

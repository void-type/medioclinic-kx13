SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [Proc_CMS_PageUrlPath_ChangeUrlCultureFormat]
	@SiteID INT,
	@CultureCode NVARCHAR(50) = NULL,
	@ModifyCulturePrefix INT,
	@DefaultCultureCode NVARCHAR(50),
	@HidePrefixForDefaultCulture BIT,
	@UseCultureAliasAsCulturePrefix BIT,
	@PageUrlPathCultureAliases Type_CMS_PageUrlPathCultureAliasesTable READONLY
AS
BEGIN
    BEGIN TRANSACTION
		BEGIN TRY
			UPDATE [CMS_PageUrlPath]
			SET [PageUrlPathUrlPath] = 
				-- Do not modify default culture prefix if is set to be hidden.
				CASE WHEN @CultureCode IS NULL AND [PageUrlPathCulture] = @DefaultCultureCode AND @HidePrefixForDefaultCulture = 1 
					THEN [PageUrlPathUrlPath]
				ELSE
					-- Add, remove or modify language prefix.
					CASE @ModifyCulturePrefix 
						WHEN 1 THEN
							-- Add prefix to URL. Use culture code or culture alias as prefix (based on @UseCultureAliasAsCulturePrefix flag and culture alias value).
							CASE WHEN @UseCultureAliasAsCulturePrefix = 1 AND (SELECT [CultureAlias] FROM @PageUrlPathCultureAliases WHERE [CultureCode] = [PageUrlPathCulture]) IS NOT NULL THEN
								(SELECT [CultureAlias] FROM @PageUrlPathCultureAliases WHERE [CultureCode] = [PageUrlPathCulture]) + '/' + [PageUrlPathUrlPath]
							ELSE
								[PageUrlPathCulture] + '/' + [PageUrlPathUrlPath]
							END
						WHEN 2 THEN
							-- Change URL language prefix to culture code or culture alias (based on @UseCultureAliasAsCulturePrefix flag and culture alias value).
							CASE WHEN @UseCultureAliasAsCulturePrefix = 1 AND (SELECT [CultureAlias] FROM @PageUrlPathCultureAliases WHERE [CultureCode] = [PageUrlPathCulture]) IS NOT NULL THEN 
								-- Remove original prefix (first segment) and add culture alias as replacement.
								(SELECT [CultureAlias] FROM @PageUrlPathCultureAliases WHERE [CultureCode] = [PageUrlPathCulture]) + '/' + SUBSTRING([PageUrlPathUrlPath], CHARINDEX('/', [PageUrlPathUrlPath]) + 1, LEN([PageUrlPathUrlPath]))
							ELSE
								-- Remove original prefix (first segment) and add culture code as replacement.
								[PageUrlPathCulture] + '/' + SUBSTRING([PageUrlPathUrlPath], CHARINDEX('/', [PageUrlPathUrlPath]) + 1, LEN([PageUrlPathUrlPath]))
							END
						ELSE
							-- Remove prefix (first segment) of the URL.
							SUBSTRING([PageUrlPathUrlPath], CHARINDEX('/', [PageUrlPathUrlPath]) + 1, LEN([PageUrlPathUrlPath]))
					END
				END,
				[PageUrlPathUrlPathHash] = 
					CASE WHEN @CultureCode IS NULL AND [PageUrlPathCulture] = @DefaultCultureCode AND @HidePrefixForDefaultCulture = 1 
						THEN CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', LOWER([PageUrlPathUrlPath])), 2)
					ELSE
						CASE @ModifyCulturePrefix 
							WHEN 1 THEN
								CASE WHEN @UseCultureAliasAsCulturePrefix = 1 AND (SELECT [CultureAlias] FROM @PageUrlPathCultureAliases WHERE [CultureCode] = [PageUrlPathCulture]) IS NOT NULL THEN
									CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', LOWER((SELECT [CultureAlias] FROM @PageUrlPathCultureAliases WHERE [CultureCode] = [PageUrlPathCulture]) + '/' + [PageUrlPathUrlPath])), 2)
								ELSE
									CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', LOWER([PageUrlPathCulture] + '/' + [PageUrlPathUrlPath])), 2)
								END
							WHEN 2 THEN
								CASE WHEN @UseCultureAliasAsCulturePrefix = 1 AND (SELECT [CultureAlias] FROM @PageUrlPathCultureAliases WHERE [CultureCode] = [PageUrlPathCulture]) IS NOT NULL THEN 
									CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', LOWER((SELECT [CultureAlias] FROM @PageUrlPathCultureAliases WHERE [CultureCode] = [PageUrlPathCulture]) + '/' + SUBSTRING([PageUrlPathUrlPath], CHARINDEX('/', [PageUrlPathUrlPath]) + 1, LEN([PageUrlPathUrlPath])))), 2)
								ELSE
									CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', LOWER([PageUrlPathCulture] + '/' + SUBSTRING([PageUrlPathUrlPath], CHARINDEX('/', [PageUrlPathUrlPath]) + 1, LEN([PageUrlPathUrlPath])))), 2)
								END
							ELSE
								CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', LOWER(SUBSTRING([PageUrlPathUrlPath], CHARINDEX('/', [PageUrlPathUrlPath]) + 1, LEN([PageUrlPathUrlPath])))), 2)
						END
					END
			WHERE [PageUrlPathSiteID] = @SiteID AND (@CultureCode IS NULL OR [PageUrlPathCulture] = @CultureCode)
		END TRY
		BEGIN CATCH
			IF XACT_STATE() = 1
			BEGIN
				DECLARE @CollisionPaths TABLE(
					[PathID] INT NOT NULL, 
					[NewPath] NVARCHAR(2000) NOT NULL,
					[OldPath] NVARCHAR(2000) NOT NULL,
					[Culture] NVARCHAR(50) NOT NULL)
				
				DECLARE @AltUrl TABLE(
					[AlternativeUrl] NVARCHAR(450) NOT NULL
				)

				INSERT INTO @AltUrl
					SELECT [AlternativeUrlUrl]				
					FROM [CMS_AlternativeUrl] [A1]
					WHERE NOT EXISTS 
						(SELECT 1 FROM [CMS_AlternativeUrl] [A2] 
							WHERE [A1].[AlternativeUrlUrl] LIKE [A2].[AlternativeUrlUrl] + '/%' 
								AND [A1].[AlternativeUrlSiteID] = [A2].[AlternativeUrlSiteID])
						AND [A1].[AlternativeUrlSiteID] = @SiteID;

				INSERT INTO @CollisionPaths 
					SELECT 
						[PageUrlPathID] AS [PathID], 
						[PageUrlPathUrlPath] + '-' + LOWER(CONVERT(VARCHAR(32), HASHBYTES('MD5', LOWER([PageUrlPathUrlPath] + [PageUrlPathCulture] + CONVERT(NVARCHAR(36), [NodeGUID]))), 2)) AS [NewPath],
						[PageUrlPathUrlPath] AS [OldPath],
						[PageUrlPathCulture] AS [Culture]
					FROM [CMS_PageUrlPath] [P]
					INNER JOIN [CMS_Tree] ON [NodeID] = [PageUrlPathNodeID]
					INNER JOIN @AltUrl [A] ON [A].[AlternativeUrl] = 
						CASE WHEN @CultureCode IS NULL AND [P].[PageUrlPathCulture] = @DefaultCultureCode AND @HidePrefixForDefaultCulture = 1 
							THEN [P].[PageUrlPathUrlPath] 
						ELSE
							CASE @ModifyCulturePrefix 
								WHEN 1 THEN
									CASE @UseCultureAliasAsCulturePrefix WHEN 1 THEN
										(SELECT [CultureAlias] FROM @PageUrlPathCultureAliases WHERE [CultureCode] = [P].[PageUrlPathCulture]) + '/' + [P].[PageUrlPathUrlPath]
									ELSE
										[P].[PageUrlPathCulture] + '/' + [P].[PageUrlPathUrlPath]
									END
								WHEN 2 THEN
									CASE WHEN @UseCultureAliasAsCulturePrefix = 1 AND (SELECT [CultureAlias] FROM @PageUrlPathCultureAliases WHERE [CultureCode] = [P].[PageUrlPathCulture]) IS NOT NULL THEN
										(SELECT [CultureAlias] FROM @PageUrlPathCultureAliases WHERE [CultureCode] = [P].[PageUrlPathCulture]) + '/' + SUBSTRING([P].[PageUrlPathUrlPath], CHARINDEX('/', [P].[PageUrlPathUrlPath]) + 1, LEN([P].[PageUrlPathUrlPath]))
									ELSE
										[P].[PageUrlPathCulture] + '/' + SUBSTRING([P].[PageUrlPathUrlPath], CHARINDEX('/', [P].[PageUrlPathUrlPath]) + 1, LEN([P].[PageUrlPathUrlPath]))
									END
								ELSE 
									SUBSTRING([P].[PageUrlPathUrlPath], CHARINDEX('/', [P].[PageUrlPathUrlPath]) + 1, LEN([P].[PageUrlPathUrlPath]))
								END
						END
					WHERE [PageUrlPathSiteID] = @SiteID AND (@CultureCode IS NULL OR [PageUrlPathCulture] = @CultureCode)

				INSERT INTO @CollisionPaths
					SELECT
						[P].[PageUrlPathID] AS [PathID], 
						[C].[NewPath] + SUBSTRING([P].[PageUrlPathUrlPath], LEN([C].[OldPath]) + 1, LEN([P].[PageUrlPathUrlPath])) AS [NewPath],
						[P].[PageUrlPathUrlPath] AS [OldPath],
						[P].[PageUrlPathCulture] AS [Culture]
					FROM @CollisionPaths [C]
					INNER JOIN [CMS_PageUrlPath] [P] ON [P].[PageUrlPathUrlPath] LIKE [C].[OldPath] + '/%'
					WHERE [P].[PageUrlPathSiteID] = @SiteID  AND (@CultureCode IS NULL OR [P].[PageUrlPathCulture] = @CultureCode) AND [C].[Culture] = [P].[PageUrlPathCulture]
								
				UPDATE [P]
				SET [P].[PageUrlPathUrlPath] = 
						CASE WHEN @CultureCode IS NULL AND [P].[PageUrlPathCulture] = @DefaultCultureCode AND @HidePrefixForDefaultCulture = 1 
							THEN COALESCE([C].[NewPath], [P].[PageUrlPathUrlPath]) 
						ELSE
							CASE @ModifyCulturePrefix
							WHEN 1 THEN
								CASE WHEN @UseCultureAliasAsCulturePrefix = 1 AND (SELECT [CultureAlias] FROM @PageUrlPathCultureAliases WHERE [CultureCode] = [P].[PageUrlPathCulture]) IS NOT NULL THEN
									(SELECT [CultureAlias] FROM @PageUrlPathCultureAliases WHERE [CultureCode] = [P].[PageUrlPathCulture]) + '/' + COALESCE([C].[NewPath], [P].[PageUrlPathUrlPath])
								ELSE
									[P].[PageUrlPathCulture] + '/' + COALESCE([C].[NewPath], [P].[PageUrlPathUrlPath])
								END
							WHEN 2 THEN
								CASE WHEN @UseCultureAliasAsCulturePrefix = 1 AND (SELECT [CultureAlias] FROM @PageUrlPathCultureAliases WHERE [CultureCode] = [P].[PageUrlPathCulture]) IS NOT NULL THEN
									(SELECT [CultureAlias] FROM @PageUrlPathCultureAliases WHERE [CultureCode] = [P].[PageUrlPathCulture]) + '/' + SUBSTRING(COALESCE([C].[NewPath], [P].[PageUrlPathUrlPath]) , CHARINDEX('/', COALESCE([C].[NewPath], [P].[PageUrlPathUrlPath])) + 1, LEN(COALESCE([C].[NewPath], [P].[PageUrlPathUrlPath])))
								ELSE
									[P].[PageUrlPathCulture] + '/' + SUBSTRING(COALESCE([C].[NewPath], [P].[PageUrlPathUrlPath]), CHARINDEX('/', COALESCE([C].[NewPath], [P].[PageUrlPathUrlPath])) + 1, LEN(COALESCE([C].[NewPath], [P].[PageUrlPathUrlPath])))
								END
							ELSE 
								SUBSTRING(COALESCE([C].[NewPath], [P].[PageUrlPathUrlPath]), CHARINDEX('/', COALESCE([C].[NewPath], [P].[PageUrlPathUrlPath])) + 1, LEN(COALESCE([C].[NewPath], [P].[PageUrlPathUrlPath])))
							END
						END,
					[P].[PageUrlPathUrlPathHash] =
						CASE WHEN @CultureCode IS NULL AND [P].[PageUrlPathCulture] = @DefaultCultureCode AND @HidePrefixForDefaultCulture = 1 
							THEN CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', LOWER(COALESCE([C].[NewPath], [P].[PageUrlPathUrlPath]))), 2) 
						ELSE
							CASE @ModifyCulturePrefix 
							WHEN 1 THEN
								CASE WHEN @UseCultureAliasAsCulturePrefix = 1 AND (SELECT [CultureAlias] FROM @PageUrlPathCultureAliases WHERE [CultureCode] = [P].[PageUrlPathCulture]) IS NOT NULL THEN
									CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', LOWER((SELECT [CultureAlias] FROM @PageUrlPathCultureAliases WHERE [CultureCode] = [P].[PageUrlPathCulture]) + '/' + COALESCE([C].[NewPath], [P].[PageUrlPathUrlPath]))), 2)
								ELSE
									CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', LOWER([P].[PageUrlPathCulture] + '/' + COALESCE([C].[NewPath], [P].[PageUrlPathUrlPath]))), 2)
								END
							WHEN 2 THEN
								CASE WHEN @UseCultureAliasAsCulturePrefix = 1 AND (SELECT [CultureAlias] FROM @PageUrlPathCultureAliases WHERE [CultureCode] = [P].[PageUrlPathCulture]) IS NOT NULL THEN
									CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', LOWER((SELECT [CultureAlias] FROM @PageUrlPathCultureAliases WHERE [CultureCode] =[P].[PageUrlPathCulture]) + '/' + SUBSTRING(COALESCE([C].[NewPath], [P].[PageUrlPathUrlPath]), CHARINDEX('/', COALESCE([C].[NewPath], [P].[PageUrlPathUrlPath])) + 1, LEN(COALESCE([C].[NewPath], [P].[PageUrlPathUrlPath]))))), 2)
								ELSE
									CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', LOWER([P].[PageUrlPathCulture] + '/' + SUBSTRING(COALESCE([C].[NewPath], [P].[PageUrlPathUrlPath]), CHARINDEX('/', COALESCE([C].[NewPath], [P].[PageUrlPathUrlPath])) + 1, LEN(COALESCE([C].[NewPath], [P].[PageUrlPathUrlPath]))))), 2)
								END
							ELSE
								CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', LOWER(SUBSTRING(COALESCE([C].[NewPath], [P].[PageUrlPathUrlPath]), CHARINDEX('/', COALESCE([C].[NewPath], [P].[PageUrlPathUrlPath])) + 1, LEN(COALESCE([C].[NewPath], [P].[PageUrlPathUrlPath]))))), 2)
							END
						END
				FROM [CMS_PageUrlPath] [P]
				LEFT JOIN @CollisionPaths [C] ON [P].[PageUrlPathID] = [C].[PathID]
				WHERE [P].[PageUrlPathSiteID] = @SiteID AND (@CultureCode IS NULL OR [P].[PageUrlPathCulture] = @CultureCode)
			END
			ELSE
			BEGIN
				ROLLBACK TRANSACTION	
			END
		END CATCH	
	COMMIT TRANSACTION
END
GO

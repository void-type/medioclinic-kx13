SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[Proc_Newsletter_Emails_FetchEmailsToSend]
	@FetchFailed bit,
	@FirstEmailID int,
	@FirstEmailGuid uniqueidentifier,
	@IssueID int,
	@TopN int,
	@IsVariant bit,
	@LastSendAttempt datetime2(7)
	AS
	BEGIN

		SET NOCOUNT ON;

		IF @IsVariant = 0
		BEGIN
			;WITH q AS
			(
				SELECT TOP (@TopN) [EmailID], [EmailNewsletterIssueID],[EmailSubscriberID],[EmailSiteID],
				[EmailLastSendResult],[EmailLastSendAttempt],[EmailSending],[EmailGUID],[EmailContactID],[EmailAddress]
					FROM Newsletter_Emails 
					WHERE EmailID > @FirstEmailID 
						AND (EmailSending IS NULL OR EmailSending = 0) 
						AND EmailNewsletterIssueID = @IssueID
						AND (
							(@FetchFailed = 0 AND (EmailLastSendResult IS NULL OR EmailLastSendResult LIKE '')) 
							OR @FetchFailed = 1
						)
					ORDER BY EmailID
			)		
			UPDATE q SET 
				EmailSending = 1, 
				EmailLastSendResult = NULL, 
				EmailLastSendAttempt = @LastSendAttempt
				OUTPUT INSERTED.[EmailID], INSERTED.[EmailNewsletterIssueID], INSERTED.[EmailSubscriberID] , INSERTED.[EmailSiteID], INSERTED.[EmailLastSendResult],
					INSERTED.[EmailLastSendAttempt], INSERTED.[EmailSending], INSERTED.[EmailGUID], INSERTED.[EmailContactID], INSERTED.[EmailAddress]
		END
		ELSE
		BEGIN
			BEGIN
				;WITH q AS
				(
					SELECT TOP (@TopN) [EmailID], [EmailNewsletterIssueID],[EmailSubscriberID],[EmailSiteID],
					[EmailLastSendResult],[EmailLastSendAttempt],[EmailSending],[EmailGUID],[EmailContactID],[EmailAddress]
						FROM Newsletter_Emails 
							WHERE 
							EmailGUID > @FirstEmailGuid
							AND (EmailSending IS NULL OR EmailSending = 0) 
							AND EmailNewsletterIssueID = @IssueID 
							AND (
								(@FetchFailed = 0 AND (EmailLastSendResult IS NULL OR EmailLastSendResult LIKE '')) 
								OR @FetchFailed = 1
							)
						ORDER BY EmailGUID
				)		
				UPDATE q SET 
					EmailSending = 1, 
					EmailLastSendResult = NULL, 
					EmailLastSendAttempt = @LastSendAttempt
					OUTPUT INSERTED.[EmailID], INSERTED.[EmailNewsletterIssueID], INSERTED.[EmailSubscriberID] , INSERTED.[EmailSiteID], INSERTED.[EmailLastSendResult],
						INSERTED.[EmailLastSendAttempt], INSERTED.[EmailSending], INSERTED.[EmailGUID], INSERTED.[EmailContactID], INSERTED.[EmailAddress]
			END
		END

	END
GO

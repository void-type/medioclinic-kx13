SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[View_OM_AccountContact_AccountJoined] AS 
SELECT     OM_Account.AccountID, OM_Account.AccountName, OM_AccountContact.ContactID, OM_AccountContact.AccountContactID, 
                      OM_AccountContact.ContactRoleID, OM_Account.AccountCountryID, OM_Account.AccountStatusID
FROM         OM_AccountContact INNER JOIN
                      OM_Account ON OM_AccountContact.AccountID = OM_Account.AccountID
GO

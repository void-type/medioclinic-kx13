SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[Proc_OM_RemoveDataFromWebAnalytics]
@Name nvarchar(100),
	@SiteID int
AS
BEGIN
	SET NOCOUNT ON	

	DECLARE @rows INT;
	DECLARE @batchSize INT;

	SET @batchSize = 25000;
	
	SELECT StatisticsID INTO #StatisticsIDs
	FROM Analytics_Statistics WHERE
        (StatisticsCode LIKE 'abconversion;'+ @Name + ';%' OR
         StatisticsCode LIKE 'absessionconversionfirst;' + @Name + ';%' OR
         StatisticsCode LIKE 'absessionconversionrecurring;' + @Name + ';%' OR
         StatisticsCode LIKE 'abvisitfirst;' + @Name + ';%' OR
         StatisticsCode LIKE 'abvisitreturn;' + @Name + ';%') AND
         StatisticsSiteID = @SiteID
	ORDER BY StatisticsID ASC

	DELETE A FROM Analytics_YearHits A INNER JOIN #StatisticsIDs ON HitsStatisticsID = StatisticsID

	DELETE A FROM Analytics_MonthHits A INNER JOIN #StatisticsIDs ON HitsStatisticsID = StatisticsID
	
	SET @rows = 1;
	WHILE @rows > 0
	BEGIN
		DELETE TOP (@batchSize) A FROM Analytics_WeekHits A INNER JOIN #StatisticsIDs ON HitsStatisticsID = StatisticsID
		SET @rows = @@ROWCOUNT
	END
	 
	SET @rows = 1;
	WHILE @rows > 0
	BEGIN
		DELETE TOP (@batchSize) A FROM Analytics_DayHits A INNER JOIN #StatisticsIDs ON HitsStatisticsID = StatisticsID
		SET @rows = @@ROWCOUNT
	END
	 
	SET @rows = 1;
	WHILE @rows > 0
	BEGIN
		DELETE TOP (@batchSize) A FROM Analytics_HourHits A INNER JOIN #StatisticsIDs ON HitsStatisticsID = StatisticsID
		SET @rows = @@ROWCOUNT
	END
		
	DELETE A FROM Analytics_Statistics A INNER JOIN #StatisticsIDs T ON A.StatisticsID = T.StatisticsID		

	DROP TABLE #StatisticsIDs
END
GO
